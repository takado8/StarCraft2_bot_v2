Put these maps into:
C:\Program Files (x86)\StarCraft II\Maps